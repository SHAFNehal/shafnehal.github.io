# -*- coding: utf-8 -*-
"""
Created on Sun Oct 27 00:15:29 2019

This code will help to explore the data using different learning models.

@author: Syed Hasib Akhter Faruqui
@email : syed-hasb-akhter.faruqui@my.utsa.edu
Website: www.shafnehal.com
"""
## Load library
import numpy as np
import pickle as p

# For Confusion Matrix
from sklearn.metrics import confusion_matrix
# PLotting purpose
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_style(style='dark')

# Open the pickle file
pickle_open = open('Training_Data.pickle','rb')
TRAINING_DATA = p.load(pickle_open)

# Check the data Size
print('Data size:',np.shape(TRAINING_DATA)[0])

# Let's check some of the data from the image files
count = 1
for i in TRAINING_DATA:
    plt.subplot(10,10, count)
    plt.imshow(i[0], cmap='gray')
    plt.axis('off')
    count += 1 
    if count == 101:
        break
#plt.tight_layout()
plt.savefig("Image.png")
    
# Let's Separate our data and class for the model calculations
X = []
y = []

for Image, Label in TRAINING_DATA:
    X.append(Image / 255) # We are appending the images as well as normalizing the data between 0 and 1. 
    y.append(Label)


# Let's check the class balance (Uncomment the following Line)
#plt.bar(y, 1)

# Get Missclassification Index
# This function will return the indices for which the model have misclassified
def MissClassedImageIndex(y_Test, y_predict1):
    MissClass = (y_Test == y_predict1)
    
    MissClass1 = []
    for i in MissClass:
        MissClass1.append(not i)
        
    Index = np.where(MissClass1)[0]
    return Index

#Check the missclassed data
# This function will plot some of the misclassified images for Error Analysis

def MissClassedImage(y_Test, y_predict, Image_Size, Num_of_Image = 25, Reshape = True):
    Index = MissClassedImageIndex(y_Test, y_predict)
    
    MissClassedImage = X_Test[Index]
    
    # Reshape the data
    if Reshape:
        MissClassedImage2 = MissClassedImage.reshape(-1, Image_Size, Image_Size)
        
    # Write the alternate case later
    plt.figure()
    # LEt's plot it
    count = 1
    for i in MissClassedImage2:
        plt.subplot(np.sqrt(Num_of_Image),np.sqrt(Num_of_Image), count)
        plt.imshow(i, cmap='gray')
        plt.axis('off')
        count += 1 
        if count == Num_of_Image + 1:
            break
    

## Function for confusion matrix
def Confusion_Matrix(y_Test, y_predict):
    # Confusion Matrix
    classes = ['Dogs', 'Cats']
    CM = confusion_matrix(y_Test, y_predict)
    fig, ax = plt.subplots()
    im = ax.imshow(CM, interpolation='nearest', cmap=plt.cm.Blues)
    ax.figure.colorbar(im, ax=ax)
    # We want to show all ticks...
    ax.set(xticks=np.arange(CM.shape[1]),
           yticks=np.arange(CM.shape[0]),
           # label them with the respective list entries
           xticklabels=classes, yticklabels=classes,
           ylabel='True (label)',
           xlabel='Predicted (label)')
    
    # Rotate the tick labels and set their alignment.
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right",
             rotation_mode="anchor")
    
    # Loop over data dimensions and create text annotations.
    for i in range(CM.shape[0]):
        for j in range(CM.shape[1]):
            ax.text(j, i, format(CM[i, j], 'd'),
                    ha="center", va="center",
                    color="black")
    fig.tight_layout()


# We need to modify the data, let's think as each pixel as a variable and numpy array. 
Image_Size = X[0].shape[0]
X_reshaped = np.array(X).reshape(-1, Image_Size * Image_Size) # -1 refers to the shape of that part will be calculated by numpy automatically

# The shape of the reshaped image
print('Shape of the Inages',X_reshaped.shape)

# Let's Split the data into Train-Test
data_split = int(.7 * len(y))
X_Train = X_reshaped[:data_split]
y_Train = y[:data_split]
X_Test  = X_reshaped[data_split:]
y_Test  = y[data_split:]

# Number of Cat class in Train and Test Data
print('Cat classes in Train Data:', (np.sum(y_Train) / len(y_Train)) *100, '%' )
print('Cat classes in Test Data:' , (np.sum(y_Test)  / len(y_Test))  *100, '%' )


############################################################
# Let's start with our baseline model
# Logistic Regression
from sklearn.linear_model import LogisticRegression
# Set the model
Model_Logistic = LogisticRegression()

# Fit the model
Model_Logistic.fit(X_Train, y_Train)

# Model Score (Accuracy)
Score1 = Model_Logistic.score(X_Test, y_Test) * 100
print('Test Accuracy: %3.2f' % Score1, '%')

# Plot the confusion matrix to assess the performance
y_predict1 = Model_Logistic.predict(X_Test)
Confusion_Matrix(y_Test, y_predict1)

# Plot Some of the missclassified Data
MissClassedImage(y_Test, y_predict1, Image_Size = 64, Num_of_Image = 25, Reshape = True)
plt.suptitle('Logistic Classification')

############################################################
# Let's Check with the decision tree
from sklearn.tree import DecisionTreeClassifier
# Set the model
Model_DT = DecisionTreeClassifier()

# Fit the model
Model_DT.fit(X_Train, y_Train)

# Model Score (Accuracy)
Score2 = Model_DT.score(X_Test, y_Test) * 100
print('Test Accuracy: %3.2f' % Score2, '%')

# Plot the confusion matrix to assess the performance
y_predict2 = Model_DT.predict(X_Test)
Confusion_Matrix(y_Test, y_predict2)

# Plot Some of the missclassified Data
MissClassedImage(y_Test, y_predict2, Image_Size = 64, Num_of_Image = 25, Reshape = True)
plt.suptitle('DT Classification')

############################################################
# Let's Check with Random forest
from sklearn.ensemble import RandomForestClassifier
# Set the model
Model_RF = RandomForestClassifier()

# Fit the model
Model_RF.fit(X_Train, y_Train)

# Model Score (Accuracy)
Score3 = Model_RF.score(X_Test, y_Test) * 100
print('Test Accuracy: %3.2f' % Score3, '%')

# Plot the confusion matrix to assess the performance
y_predict3 = Model_RF.predict(X_Test)
Confusion_Matrix(y_Test, y_predict3)

# Plot Some of the missclassified Data
MissClassedImage(y_Test, y_predict3, Image_Size = 64, Num_of_Image = 25, Reshape = True)
plt.suptitle('RF Classification')

############################################################
'''
Before we proceed to Neural Networks, I would like to mention the following portion
needs tensorflow library. If you are using Anaconda then run the following lines of 
codes in Anaconda command prompt.

conda install -c conda-forge tensorflow
pip install keras
pip install keract

'''
############################################################

# Let's setup a Neural Network
# We will be using keras library (Tensorflow for this)
from keras.models import Sequential
from keras.layers import Dense, Dropout
from keras.optimizers import SGD
from keras.utils import to_categorical


# Define initial parameters
N_classes = 2
epochs = 100
Input_Shape = X_Test.shape[1]

# For this we need to modify out y_Test and y_Train (One hot encoding)
y_binary_Train = to_categorical(y_Train)
y_binary_Test = to_categorical(y_Test)

# Define the model
# Here we defined our layers.

# Start The model definition
model = Sequential()
# Later 1
model.add(Dense(512, activation='relu', input_shape=(Input_Shape,)))
model.add(Dropout(0.2))
# Later 2
model.add(Dense(512, activation='relu'))
model.add(Dropout(0.2))
# Later 3
model.add(Dense(N_classes, activation='softmax'))

# Compiling the model with 
# 			loss function : Categorical Cross Entropy
# 			Optimizer     : Stochastic Gradient Descent
model.compile(loss='categorical_crossentropy',
              optimizer=SGD(),
              metrics=['accuracy'])
# Fit/ Train the model
history = model.fit(X_Train, y_binary_Train,
                    batch_size=50,
                    epochs=epochs,
                    verbose=1,
                    validation_data=(X_Test, y_binary_Test))

# Evaluate the model Performance
score4 = model.evaluate(X_Test, y_binary_Test, verbose=0)

print('Test loss:', score4[0])
print('NN Test accuracy:', (score4[1]*100),'%')

# Plot the confusion matrix to assess the performance
y_predict4 = model.predict_classes(X_Test)
Confusion_Matrix(y_Test, y_predict4)

# Plot Some of the missclassified Data
MissClassedImage(y_Test, y_predict4, Image_Size = 64, Num_of_Image = 25, Reshape = True)
plt.suptitle('NN classification')

############################################################



















