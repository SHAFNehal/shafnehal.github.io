# -*- coding: utf-8 -*-
"""
Created on Sun Oct 27 03:20:00 2019

This code will help to explore the data using CNNs.

@author: Syed Hasib Akhter Faruqui
@email : syed-hasb-akhter.faruqui@my.utsa.edu
Website: www.shafnehal.com
"""
## Load library
import numpy as np
import pickle as p

# For Confusion Matrix
from sklearn.metrics import confusion_matrix

# CNN Functions
from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation, Flatten, Conv2D, MaxPooling2D
from keras.optimizers import SGD
from keras.utils import to_categorical


# PLotting purpose
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_style(style='dark')

## Function for confusion matrix
def Confusion_Matrix(y_Test, y_predict):
    # Confusion Matrix
    classes = ['Dogs', 'Cats']
    CM = confusion_matrix(y_Test, y_predict)
    fig, ax = plt.subplots()
    im = ax.imshow(CM, interpolation='nearest', cmap=plt.cm.Blues)
    ax.figure.colorbar(im, ax=ax)
    # We want to show all ticks...
    ax.set(xticks=np.arange(CM.shape[1]),
           yticks=np.arange(CM.shape[0]),
           # ... and label them with the respective list entries
           xticklabels=classes, yticklabels=classes,
           ylabel='True label',
           xlabel='Predicted label')
    
    # Rotate the tick labels and set their alignment.
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right",
             rotation_mode="anchor")
    
    # Loop over data dimensions and create text annotations.
    for i in range(CM.shape[0]):
        for j in range(CM.shape[1]):
            ax.text(j, i, format(CM[i, j], 'd'),
                    ha="center", va="center",
                    color="black")
    fig.tight_layout()
    
# Open the pickle file
pickle_open = open('Training_Data.pickle','rb')
TRAINING_DATA = p.load(pickle_open)

# Check the data Size
print('Data size:',np.shape(TRAINING_DATA)[0])

# Let's Separate our data and class for the model calculations
X = []
y = []

for Image, Label in TRAINING_DATA:
    X.append(Image / 255) # We are appending the images as well as normalizing the data between 0 and 1. 
    y.append(Label)


# For Convolution Neural Networks we will be modifying the data again as CNN's use image directly
X_reshaped = np.array(X).reshape(np.shape(X)[0], np.shape(X)[1], np.shape(X)[2], 1)
y_binary   = to_categorical(y)

# Let's Split the data into Train-Test
data_split = int(.7 * len(y))
X_Train = X_reshaped[:data_split]
y_Train = y_binary[:data_split]
X_Test  = X_reshaped[data_split:]
y_Test  = y_binary[data_split:]

# Define initial parameters
N_classes = 2
epochs = 10
Input_Shape = X_Test.shape[1]

# Let's build the CNN Model
model = Sequential()
# Later 1
model.add(Conv2D(12, (3, 3), input_shape=X_reshaped.shape[1:]))
model.add(Activation('relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))
# Later 2
model.add(Conv2D(12, (3, 3)))
model.add(Activation('relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))

model.add(Flatten())  # this converts our 3D feature maps to 1D feature vectors
# Later 3
model.add(Dense(64))
# Later 4
model.add(Dense(N_classes))
model.add(Activation('sigmoid'))

# Compiling the model with 
# 			loss function : Categorical Cross Entropy
# 			Optimizer     : Stochastic Gradient Descent
model.compile(loss='categorical_crossentropy',
              optimizer=SGD(),
              metrics=['accuracy'])
# Fit/ Train the model
model.fit(X_Train, y_Train, 
          batch_size=100, 
          epochs=epochs, 
          validation_data=(X_Test, y_Test))

score = model.evaluate(X_Test, y_Test, verbose=0)

print('Test loss:', score[0])
print('CNN Test Accuracy: %3.2f' % (score[1]*100), '%')

# Plot the confusion matrix to assess the performance
y_predict5 = model.predict_classes(X_Test)
Confusion_Matrix(y[data_split:], y_predict5)
############################################################
# Get Missclassification Index
def MissClassedImageIndex(y_Test, y_predict1):
    MissClass = (y_Test == y_predict1)
    
    MissClass1 = []
    for i in MissClass:
        MissClass1.append(not i)
        
    Index = np.where(MissClass1)[0]
    return Index

#Check the missclassed data
def MissClassedImage(y_Test, y_predict,Image_Size, Num_of_Image = 25, Reshape = True):
    Index = MissClassedImageIndex(y_Test, y_predict)
    
    MissClassedImage = X_Test[Index]
    
    # Reshape the data
    if Reshape:
        MissClassedImage2 = MissClassedImage.reshape(-1, Image_Size, Image_Size)
    plt.figure()
    # Write the alternate case later
    # LEt's plot it
    count = 1
    for i in MissClassedImage2:
        plt.subplot(np.sqrt(Num_of_Image),np.sqrt(Num_of_Image), count)
        plt.imshow(i, cmap='gray')
        plt.axis('off')
        count += 1 
        if count == Num_of_Image + 1:
            break

# Plot Some of the missclassified Data
MissClassedImage(np.argmax(y_Test, axis=-1), y_predict5, Image_Size = 64, Num_of_Image = 25, Reshape = True)
plt.suptitle('CNN Regression')

### Testing
# get the symbolic outputs of each "key" layer (we gave them unique names).
layer_dict = dict([(layer.name, layer) for layer in model.layers])

# check one image [0:DOG, 1:CAT]
#X_Test[0:1]
#y_Train[1]

##########################################################
'''
This portion of the code will help you inspect the layers in CNN for feature properties and error analysis
'''
##########################################################
# Check layers
import keract as k

# Dog Image (Correctly classified One)
activations = k.get_activations(model, X_Test[0:1], 'activation_1')

first = activations.get('block1_conv1/Relu:0')
k.display_activations(activations)

# CAT Image (Misclassified one)
activations = k.get_activations(model, X_Test[3:4], 'activation_1')

first = activations.get('block1_conv1/Relu:0')
k.display_activations(activations)
