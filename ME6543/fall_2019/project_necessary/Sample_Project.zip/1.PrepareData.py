# -*- coding: utf-8 -*-
"""
Created on Sun Oct 27 00:15:29 2019

This code will read the images in data folder and create an array of the images and store it as a list
with the class identification. 
Next it will save the data list as a pickle file for future convenience.

@author: Syed Hasib Akhter Faruqui
@email : syed-hasb-akhter.faruqui@my.utsa.edu
Website: www.shafnehal.com
"""

## Load library
import numpy as np
import random as rnd
import os   # Helps with durectory management
# To read imagefiles
import cv2  # For Image File we will need this library.
# If OpenCV is ont istalled on your system, run the following lines on your "Anaconda Command Prompt"
# pip install opencv-python
import pickle as p

# PLotting purpose
import matplotlib.pyplot as plt


# First:    We will now create a function that will collect all the image files from 
#           the folders and store it as a list with class labels

def Create_Dataset(directory, cat, Updated_Size = 128):
    '''
    The data is colored photos of different size and we want them to be
        1. Gray Scalled
        2. Normalized
        3. Shape the images to a constant shape (the provided ones are of different shapes)
            i. let's say we want them to be in square size
            ii. say the image will be of size of "64x64" (8 bit multiplier)
    '''
    # Store all the data in a single data tensor or list
    training_data = []
    # We will iterate over the two class categories namely "Dog" and "Cat"
    for Category in cat:
        # Access each category folder
        path = os.path.join(directory, Category) # Path to datasets
        # Define the class 
        class_num = cat.index(Category)
        # Let's load the data one by one and 
        #   1. Convert the data into Grey Scale
        #   2. Resize the images to a shape of our choice
        for image in os.listdir(path):    # Explore the path
            # Let's also keep a failsafe here! In case any image is broken or there are any errors in the image
            # we should be able to ignore those!
            try:    
                # We grey scaled the images here
                current_image = cv2.imread(os.path.join(path, image), cv2.IMREAD_GRAYSCALE) # Convert the images to array
                # Now we resize it
                resized_image = cv2.resize(current_image, (Updated_Size, Updated_Size))
                # Now let's store the data in list
                training_data.append([resized_image, class_num])
			# For any exception error Ignore that Image from reading
            except Exception:
                pass

    return training_data


## Create the training data by running the function
# Updated image Size
Updated_Size = 64
# Data Directory Setting
directory   = r'C:\Users\insul\Desktop\Data_Mining_Course_UTSA\0.Sample_Project\Classification_Problem\Dataset\PetImages'
# Categories
cat         = ['Dog', 'Cat'] # 0 = Dog and 1 = Cat
# Training Data
TRAINING_DATA = Create_Dataset(directory, cat, Updated_Size)

# Let's check the data size
print('Training data size:',np.shape(TRAINING_DATA)[0])

# Let's inspect one of the datas
plt.imshow(TRAINING_DATA[0][0])
plt.imshow(TRAINING_DATA[24945][0])

# Let's mix the data's by randomizing it as the first half of observations are dogs and rest are cats or vice-versa
rnd.shuffle(TRAINING_DATA)

# Next step: We can save the data as an arary so that next time we can load the data much easily 
# instead of running this code again. And offcourse it will take your time and consume computational efforts to
# again pack them in array. 
# To do that we will create a pickel (A file format to store data) file.
pickle_save = open('Training_Data.pickle','wb')
p.dump(TRAINING_DATA, pickle_save)
pickle_save.close()















