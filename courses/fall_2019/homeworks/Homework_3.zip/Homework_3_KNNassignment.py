#!/usr/bin/env python
# coding: utf-8

# # Homework 3
# You will complete the following peice of code for KNN regression
# There are two parts in the code that needs your attention, **QUESTION 1** and **QUESTION 2**
# 
# 
# N.B. You are only allowed to use basic functions from numpy and scipy

# In[ ]:


# Import Library
import numpy as np


# In[ ]:


# Create the Data
# Train Data
x_train=np.array([[0,0],[1,0],[0,1],[1,1],[1,4],[4,1],[2,2]])  # input values of the training set
y_train=np.array([1,2,2,2,4,6,3])                              # output values of the training set
# Test Data
x_test=np.array([3,3])                                         # input values of the test set


# # QUESTION 1
# Write a function names **"Eucdist"** that calculate/return the distance between a test point(x_test) and all training points (x_train) as a vector

# In[ ]:


# distance Function
def Eucdist(x_test,x_train):
    Distance =                            # Enter Your equation for Eucledian Distance
    return Distance


# In[ ]:


# Sort the Data
distance               = Eucdist(x_test, x_train)
# vertically stack the distance vector to training outputs
distance_training_data = np.transpose(np.vstack((distance,y_train))) 
# the matrix of "distance and training outputs" sort based on the calucated euclidian distance (first column)
distance_training_data_sorted=distance_training_data[distance_training_data[:,0].argsort()];


# In[ ]:


distance_training_data_sorted


# # QUESTION 2
# Write a command/function that provide the average of the first "k=3" rows of the second column of **distance_training_data_sorted** as the KNN prediction

# In[ ]:


k=3 # number of nearest neighbor to consider


# In[ ]:


def Prediction(distance_training_data_sorted, k):
    y_pred =                                        # Enter your Equation for Prediction
    return y_pred


# In[ ]:


Y_pred = Prediction(distance_training_data_sorted,k)
Y_pred


# In[ ]:




